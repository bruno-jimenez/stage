const tabs = document.querySelectorAll('.tab-item');
const plans = document.querySelectorAll('.plans');

tabs.forEach(tab => {
  tab.addEventListener('click', function() {
    tabs.forEach(item => item.classList.remove('active'));
    tab.classList.add('active');

    const target = tab.getAttribute('data-target');
    plans.forEach(plan => {
      plan.classList.remove('active');
      if (plan.id === target) {
        plan.classList.add('active');
      }
    });
  });
});
